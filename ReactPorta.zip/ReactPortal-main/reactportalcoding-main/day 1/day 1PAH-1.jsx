import React from "react";
function World()
{
    return(
      <div>
        <p>
          This is Team Functional Component
        </p>
    </div>)
}
export default World;
