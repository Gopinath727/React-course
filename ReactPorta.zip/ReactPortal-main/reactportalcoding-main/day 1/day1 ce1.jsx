import React from 'react';
const alert = () => 
{
  alert("Message from Javascript Alert!")
  console.log("Message to developer")
}
function click button()
{
 return(<div>
<h1>Let we see the output of JAVASCRIPT</h1>
  <button onClick={alerter}>Submit</button>
 </div>)
}
export default load;
