
import React from 'react';
const Album = () => {
 return (
 <div>
 <h2>Albums</h2>
 <ul>
 <li>Album 1 by Singer 1</li>
 <li>Album 2 by Singer 2</li>
 </ul>
 </div>
 );
};
export default Album;
